# 336wiki

# Orbbec Gemini 336 相机 Wiki 

![屏幕截图 2026\-10\-25 161840\.png](图片和附件/屏幕截图%202026-10-25%20161840.png)

> **产品定位**：Orbbec Gemini 336 Gemini 330 系列的 USB 双目深度相机即双红外相机、850 nm 主动红外投射和 Orbbec MX6800 ASIC 的基础上加入了 IR\-Pass 滤光盖板，并集成 RGB 相机、单点近距测距模块与 6 轴 IMU。相机可提供深度图、IR、RGB、惯性数据，以及由设备和 SDK 完成的深度对齐与点云输出。

## 特性

- **主动与被动双目结合**：内置 850 nm 激光投射模组，在弱纹理或暗光下主动投射散斑；户外或纹理丰富时也可依靠被动双目匹配。

- **IR\-Pass 滤光盖板**：允许近红外波段通过并抑制可见光进入，有效降低反光表面眩光、明暗对比强烈或室外强光对深度算法的干扰。

- **MX6800 ASIC 芯片**：相机内部完成深度计算和硬件 D2C（Depth to Color）空间对齐，降低主机侧处理负担。

- **单点 dToF 近距测距**：集成近距测距模块（LRM），补充主双目深度在极近距离的盲区（输出单点距离而非稠密深度）。

## 规格参数

|参数|Gemini 336|
|---|---|
|**深度技术**|主动与被动双目 \(IR\-Pass\)|
|**双目基线**|50 mm|
|**工作范围**|0\.10–20 m\+ \(推荐: 0\.26–3 m\)|
|**深度分辨率**|最高 1280 × 800 @ 30 fps|
|**深度视场角**|90° × 65° ± 3°|
|**RGB 最高规格**|1920 × 1080 @ 30 fps \(Rolling Shutter\)|
|**RGB 视场角**|86° × 55° ± 3° \(16:9\)|
|**空间相对精度**|≤1\.5% @ 2m \(1280×800, 90%×90% ROI\)|
|**数据接口**|USB Type\-C \(支持 USB 3\.0 / 2\.0\)|
|**防护等级**|IP5X|
|**工作温度**|\-10–45 ℃ @ 15 fps|
|**平均/峰值功耗**|\<3\.0 W / \<6\.5 W|
|**机械尺寸**|90 × 25 × 30\.7 mm \(约 99 g\)|

## 硬件概述

- **正面感知区域**：从左至右依次集成左右 IR 模组、850 nm 激光投射模组（LDM）、RGB 模组和单点激光测距模组（LRM）。深度成像区域覆盖有 IR\-Pass 滤光结构。

![rId32\.png](图片和附件/rId32%201.png)

- **数据传输与同步**：均配置 USB Type\-C 接口用于数据传输和供电；配备 8 针同步接口，支持多机硬件同步。完整数据流并发时建议使用 USB 3\.0。

![rId31\.png](图片和附件/rId31.png)

- **安装结构**：

    - 底部均提供 1/4\-20 UNC 安装孔。

    - Gemini 336 背面提供 2 × M3 安装孔；Gemini 336L 背面提供 2 × M4 安装孔。

![rId32\.png](图片和附件/rId32.png)

    

---

## 基于 Gemini 336 参数的深度图像处理

### 1\. 相机参数提取与仿真数据生成

在仿真环境中，我们将 336 的官方参数转化为代码变量，并模拟一个包含“2\.5 米处背景墙”和“1 米处矩形障碍物”的测试场景。

**提取的核心参数：**

- **分辨率**：1280 × 800 \(Y16 格式\)

- **视场角 \(FoV\)**：水平 90°，垂直 65°（焦距 $f_x \approx 640, f_y \approx 628$）

- **物理误差注入**：

    - 2\.5m 处背景墙：注入约 37mm 的高斯噪声（对应 1\.5% 相对精度）。

    - 1\.0m 处前景障碍物：注入约 10mm 的高斯噪声。

**代码文件：**

```Python
import cv2
import numpy as np

# 1. 提取 336 参数
W, H = 1280, 800
FOV_H, FOV_V = np.deg2rad(90), np.deg2rad(65) # 90度 x 65度
rng = np.random.default_rng(336) # 336专属随机种子

# 2. 初始化 16位 深度图
depth = np.zeros((H, W), dtype=np.uint16)
y, x = np.mgrid[0:H, 0:W]

# 3. 模拟 2.5米 (2500mm) 处的背景墙，1.5% 精度 (约37mm 噪声)
background = np.full((H, W), 2500, dtype=np.float32)
noise_bg = rng.normal(0, 37, size=(H, W)) 
background = np.clip(background + noise_bg, 0, 65535).astype(np.uint16)

# 4. 模拟 1米 (1000mm) 处的矩形障碍物，近处误差小 (约10mm 噪声)
obstacle_mask = (x > 350) & (x < 850) & (y > 200) & (y < 600) 
obstacle = np.full((H, W), 1000, dtype=np.float32)
noise_obs = rng.normal(0, 10, size=(H, W)) 
obstacle = np.clip(obstacle + noise_obs, 0, 65535).astype(np.uint16)

# 5. 合成图像
depth = background
depth[obstacle_mask] = obstacle[obstacle_mask]

# 6. 模拟边缘无效值 (0表示测不到)
depth[:, :50] = 0
depth[:, -50:] = 0

# 保存输出
cv2.imwrite("sim/output/336_depth16.png", depth)
print("已生成 Gemini 336 仿真深度图: sim/output/336_depth16.png")
```

**输出文件**：`sim/output/336_depth16.png`（包含近中距离物理噪点的 16 位深度图）

### 2\. 深度图像处理与 3D 点云重建

得到带有噪点的原始深度图后，使用 OpenCV 进行滤波去噪，并利用相机内参将其反投影到 3D 空间。为了区分不同相机的视觉效果，本节采用了色彩更鲜艳的 **TURBO** 色带。

**核心原理**：

1. **中值滤波**：使用 `cv2.medianBlur` 滤除边缘散斑噪声。

2. **伪彩色映射**：将近处（1m）映射为深蓝/青色，远处（2\.5m）映射为红/黄色，无效边缘置黑。

3. **内参反投影**：利用公式 $X = (u-c_x)Z/f_x$ 和 $Y = (v-c_y)Z/f_y$ 将 2D 像素还原为 3D 点云数据。

**代码文件：**

```Python
import cv2
import numpy as np

# 1. 内参计算 (90x65度)
W, H = 1280, 800
FOV_H, FOV_V = np.deg2rad(90), np.deg2rad(65)
fx = W / (2 * np.tan(FOV_H / 2))
fy = H / (2 * np.tan(FOV_V / 2))
cx, cy = W / 2, H / 2

DEPTH_PATH = "sim/output/336_depth16.png"
depth = cv2.imread(DEPTH_PATH, cv2.IMREAD_UNCHANGED)

# 2. 中值滤波去噪
depth_float = depth.astype(np.float32)
depth_filtered = cv2.medianBlur(depth_float, 5)
depth_filtered = depth_filtered.astype(np.uint16)

# 3. 伪彩色渲染 (TURBO色带)
valid = depth[depth > 0]
dmin, dmax = np.percentile(valid, [1, 99])
depth_clip = np.clip(depth.astype(np.float32), dmin, dmax)
depth_norm = ((depth_clip - dmin) / (dmax - dmin) * 255).astype(np.uint8)
depth_norm[depth == 0] = 0
depth_color = cv2.applyColorMap(depth_norm, cv2.COLORMAP_TURBO) # 使用 TURBO
cv2.imwrite("sim/output/336_vis.png", depth_color)

# 4. 2D 转 3D 点云
ys, xs = np.where(depth_filtered > 0)
z_vals = depth_filtered[ys, xs].astype(np.float32) / 1000.0 # 转成米
x_vals = (xs - cx) * z_vals / fx
y_vals = (ys - cy) * z_vals / fy
points = np.stack((x_vals, y_vals, z_vals), axis=-1)

# 5. 保存 PLY 文件
ply_header = f"""ply
format ascii 1.0
element vertex {len(points)}
property float x
property float y
property float z
end_header
"""
with open("sim/output/336_cloud.ply", "w") as f:
    f.write(ply_header)
    np.savetxt(f, points, fmt="%.4f %.4f %.4f")

print("处理完成！已生成 336_vis.png 和 336_cloud.ply")
```

### 3\. 输出结果

**可视化效果预览**：

![336\_vis\.png](图片和附件/336_vis.png)


*图：Gemini 336 仿真结果。采用 TURBO 色带渲染，深蓝色为 1m 障碍物，红黄色为 2\.5m 背景墙。*

### 4\. 环境复现指南

若要在其他机器上复现此仿真流程，请按以下步骤操作：

1. **激活专属 Conda 环境**：

```Bash
conda activate orbbec_wiki
```

2. **进入项目目录**：

```Bash
cd ~/gemini336_demo
```

3. **生成仿真深度图**：

```Bash
python sim/gen_336.py
```

4. **图像处理与点云生成**：

```Bash
python sim/process_336.py
```

