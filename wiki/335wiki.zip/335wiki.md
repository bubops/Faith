# 335wiki

# Orbbec Gemini 335  相机wiki

![rId20\.png](图片和附件/rId20.png)

**产品定位**：紧凑型 Gemini 335相机基于主动立体红外技术，配备 Orbbec 最新的定制 ASIC 芯片，用于高质量深度处理、IMU 和单线 USB 3\.0 供电\+连接。宽视场角和宽深度感知范围使其适用于许多应用，特别是机器人技术。它易于设置和操作，配合 Orbbec SDK 使用，在从完全黑暗到半户外的各种光照条件下都能提供极其准确和可靠的数据。

## 特性

- **主动立体红外**：采用主被动融合双目技术（850 nm），在弱纹理、弱光环境中补充可匹配特征，实现各种光照条件下准确可靠的数据输出。

- **宽感知范围**：Gemini 335 推荐工作范围为 0\.26m–3m；Gemini 335L 采用 95mm 长基线，推荐工作范围延伸至 0\.25m–6m。最大工作范围超过 20m（需满足特定反射率条件）。

- **宽视场角**：提供 90° 水平 × 65° 垂直的宽广深度视场角。

- **多相机同步**：支持深度图像和 RGB 图像的多相机同步（内置 8\-pin 多机同步接口）。

- **USB 连接**：使用单根 USB 3\.0 Type\-C 线缆进行供电和连接（兼容 USB 2\.0，但高带宽组合需 USB 3\.x）。

- **全局快门**：深度图像采用全局快门，Gemini 335L 的 RGB 亦采用全局快门，更利于运动场景。

## 规格参数

|参数|Gemini 335|详细说明 / 条件|
|---|---|---|
|**深度技术**|主被动融合双目，850 nm|户外主要依赖被动双目与模式配置|
|**双目基线**|95 mm|长基线提高中远距离视差分辨能力|
|**深度分辨率/帧率**|最高 1280 × 800 @ 30fps|较低分辨率可提供更高帧率|
|**RGB 分辨率/帧率**|最高 1280 × 800 @ 60fps|335偏向高彩色分辨率；335L偏向高帧率|
|**深度视场角 \(FoV\)**|90° × 65° ±3° @ 2m|1280 × 800 模式|
|**推荐工作范围**|0\.25m – 6m|选型和验收应优先围绕推荐范围|
|**空间相对精度**|≤0\.8% @ 2m；≤1\.6% @ 4m|2m 为 90%×90% ROI，4m 为 80%×80% ROI|
|**RGB 快门**|全局快门|335L 更适合快速运动或振动场景|
|**机械尺寸**|124 × 29 × 27 mm|335L 更宽，需预留线缆弯曲半径|
|**重量**|133 g|无人机等运动平台需计入惯量|
|**防护等级**|IP65|335 未声明防水；335L 防尘防喷水|
|**通信接口**|USB 3\.0 Type\-C|支持 USB 2\.0，但高分辨率需 3\.0|
|**供电**|DC 5V \(USB Type\-C\)|平均功耗 \< 3W，峰值 \< 6\.5W|
|**工作温度**|\-10℃ \~ 50℃ @ 15/30fps|高帧率会收紧最高工作温度|

## 硬件概述

![rId34\.png](图片和附件/rId34.png)

- **IR Camera \(双目\)**：左右各一个红外相机，负责视差观测（335 为 95mm）。

- **LDP**：散斑发射模块，为低纹理区域增加可匹配特征。

- **LDM / LRM**：单点激光测距模块，用于补充近距离盲区的点测距信息。

- **RGB Camera**：提供彩色图像数据。

- **MX6800**：内置深度处理芯片，在相机端完成深度计算及部分图像处理。

- **IMU**：六轴惯性测量单元，输出角速度与加速度。

- **Type\-C Interface**：USB 3\.0 Type\-C 接口，用于数据通信与供电（DC 5V, ≥1\.5A）。

- **8\-Pin Multi\-Camera Synchronization Interface**：多机同步接口，用于触发与主从配置。

---

## 基于 Gemini 335 的深度图像处理

### 1\. 相机参数提取与仿真数据生成

在仿真环境中，我们将 335的官方参数转化为代码变量，并模拟一个包含“4 米处背景墙”和“2 米处矩形障碍物”的测试场景。

- **分辨率**：1280 × 800 \(Y16 格式\)

- **视场角 \(FoV\)**：水平 90°，垂直 65°

- **物理误差**：

    - 2m 处障碍物：注入约 16mm 的高斯噪声（对应 0\.8% 相对精度）。

    - 4m 处背景墙面：注入约 64mm 的高斯噪声（对应 1\.6% 相对精度）。

**代码文件****：**

```Python
import cv2
import numpy as np

# 1. 提取 335 参数
W, H = 1280, 800
FOV_H, FOV_V = np.deg2rad(90), np.deg2rad(65) # 90度 x 65度
rng = np.random.default_rng(335) # 随机种子

# 2. 初始化 16位 深度图
depth = np.zeros((H, W), dtype=np.uint16)
y, x = np.mgrid[0:H, 0:W]

# 3. 模拟 4米 (4000mm) 处的背景墙，4m处精度 1.6% (64mm 噪声)
background = np.full((H, W), 4000, dtype=np.float32)
noise_bg = rng.normal(0, 64, size=(H, W)) 
background = np.clip(background + noise_bg, 0, 65535).astype(np.uint16)

# 4. 模拟 2米 (2000mm) 处的矩形障碍物，2m处精度 0.8% (16mm 噪声)
obstacle_mask = (x > 300) & (x < 900) & (y > 150) & (y < 650)
obstacle = np.full((H, W), 2000, dtype=np.float32)
noise_obs = rng.normal(0, 16, size=(H, W)) 
obstacle = np.clip(obstacle + noise_obs, 0, 65535).astype(np.uint16)

# 5. 合成图像
depth = background
depth[obstacle_mask] = obstacle[obstacle_mask]

# 6. 模拟边缘无效值 (0表示测不到)
depth[:, :60] = 0
depth[:, -60:] = 0

# 保存输出
cv2.imwrite("sim/output/335_depth16.png", depth)
print("已生成 Gemini 335 仿真深度图: sim/output/335_depth16.png")
```

### 2\. 深度图像处理与 3D 点云重建

得到带有噪点的原始深度图后，使用 OpenCV 进行中值滤波去噪，并通过内参反投影将 2D 像素还原为 3D 点云数据。

**代码文件：**

```Python
import cv2
import numpy as np

# 1. 内参计算 (90x65度)
W, H = 1280, 800
FOV_H, FOV_V = np.deg2rad(90), np.deg2rad(65)
fx = W / (2 * np.tan(FOV_H / 2))
fy = H / (2 * np.tan(FOV_V / 2))
cx, cy = W / 2, H / 2

DEPTH_PATH = "sim/output/335_depth16.png"
depth = cv2.imread(DEPTH_PATH, cv2.IMREAD_UNCHANGED)

# 2. 中值滤波去噪
depth_float = depth.astype(np.float32)
depth_filtered = cv2.medianBlur(depth_float, 5)
depth_filtered = depth_filtered.astype(np.uint16)

# 3. 伪彩色渲染 (生成可视化图)
valid = depth[depth > 0]
dmin, dmax = np.percentile(valid, [1, 99])
depth_clip = np.clip(depth.astype(np.float32), dmin, dmax)
depth_norm = ((depth_clip - dmin) / (dmax - dmin) * 255).astype(np.uint8)
depth_norm[depth == 0] = 0
depth_color = cv2.applyColorMap(depth_norm, cv2.COLORMAP_JET)
cv2.imwrite("sim/output/335_vis.png", depth_color)

# 4. 2D 转 3D 点云
ys, xs = np.where(depth_filtered > 0)
z_vals = depth_filtered[ys, xs].astype(np.float32) / 1000.0 # 转成米
x_vals = (xs - cx) * z_vals / fx
y_vals = (ys - cy) * z_vals / fy
points = np.stack((x_vals, y_vals, z_vals), axis=-1)

# 5. 保存 PLY 文件
ply_header = f"""ply
format ascii 1.0
element vertex {len(points)}
property float x
property float y
property float z
end_header
"""
with open("sim/output/335_cloud.ply", "w") as f:
    f.write(ply_header)
    np.savetxt(f, points, fmt="%.4f %.4f %.4f")

print("处理完成！已生成 335_vis.png 和 335_cloud.ply")
```

### 3\. 输出结果

执行完上述代码后，会生成如下效果图：

![335L\_vis\.png](图片和附件/335L_vis.png)

*注：伪彩色图中红色区域为 4m 处背景墙，蓝色区域为 2m 处前景障碍物，边缘黑色为无效值。远距离的红色背景噪点颗粒显著多于近处，真实反映了 1\.6% 误差的物理特性。*

### 4\. 环境复现指南

1. **激活专属 Conda 环境**：

```Bash
conda activate orbbec_wiki
```

2. **进入项目目录**：

```Bash
cd ~/gemini335_demo
```

3. **生成仿真深度图**：

```Bash
python sim/gen_335.py
```

4. **图像处理与点云生成**：

```Bash
python sim/process_335.py
```

