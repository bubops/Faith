# 435Le\_wiki

---

# Orbbec Gemini 435Le 3D 相机 

![rId20\.png](图片和附件/rId20.png)

> **产品定位**：Orbbec Gemini 435Le 是一款面向机器人与工业视觉集成的以太网双目 3D 相机。它直接提供深度图、左右红外图像、RGB 图像、六轴 IMU 数据、置信度图与硬件时间戳，并可通过 SDK 生成点云和完成深度到彩色的对齐。其 95 mm 双目基线、主动红外散斑辅助、全局快门、千兆以太网与 PoE 供电等特性，使其非常适合大型移动机器人、物流设备及固定式视觉工位。

## 特性

- **主动双目立体视觉**：采用 95mm 基线双目结构，配合 850nm 主动红外散斑辅助，在弱纹理或暗光条件下依然能实现准确可靠的深度输出。

- **宽量程与宽视场角**：提供 0\.31m 到 20m\+ 的宽量程深度数据（理想范围 0\.31m\-10m）。具备 90° 水平 和 65° 垂直的宽视场角。

- **全局快门传感器**：IR 与 RGB 传感器均采用全局快门，适合运动平台和动态目标采集，降低运动造成的几何畸变。

- **内置六轴 IMU**：可输出加速度与角速度，为视觉惯性融合（VIO）提供原始数据。

- **千兆以太网与 PoE**：通过 M12 X\-coded 接口传输数据，支持 PoE 供电，极大简化了机器人的布线与机电集成。

- **工业级防护与多机同步**：具备 IP67 防护等级，支持硬件级多相机同步（VSYNC）及 RS485 接口，适应严苛工业环境。

## 规格参数

|参数|详细信息|
|---|---|
|**深度技术**|双目立体视觉，850 nm 主动红外散斑辅助 \(基线 95 mm\)|
|**工作范围**|0\.31m \~ 20m\+ \(理想范围 0\.31m \~ 10m\)|
|**深度分辨率**|最高 1280 × 800 @ 10 fps；640 × 400 @ 20 fps|
|**RGB 分辨率**|最高 1280 × 800 @ 10 fps；640 × 400 @ 20 fps|
|**深度视场角**|90° × 65° ± 3° \(1280 × 800, 2m\)|
|**RGB 视场角**|94° × 68° ± 3° \(16:10\)|
|**深度准确度**|±1% 以内 @ 2m；±2% 以内 @ 4m \(1280×800\)|
|**快门类型**|IR 全局快门；RGB 全局快门|
|**数据接口**|千兆以太网 \(TCP/IP, RTSP\)，M12 X\-coded 8\-pin|
|**供电方式**|PoE IEEE 802\.3af；DC 9\-24V \(M12 A\-coded\)|
|**功耗**|DC 平均 \<6\.5W，峰值 \<11W；PoE 平均 \<8W，峰值 \<15W|
|**防护与环境**|IP67 防护；工作温度 \-10°C \~ 50°C；湿度 5%\~90% RH 无冷凝|
|**机械尺寸**|138\.5 × 40\.5 × 70\.0 mm \(裸机重量约 520g\)|

## 硬件概述

- **正面感知区域**：从左到右依次集成双 IR 红外相机、激光散斑投射模块（LDM，850nm）、RGB 相机以及近距离激光测距模块（LRM，940nm，覆盖约 1\-400mm）。

![rId23\.png](图片和附件/rId23.png)

- **背部工业连接器**：

    - **M12 X\-coded 接口**：用于千兆以太网数据传输及 PoE 供电。

    - **M12 A\-coded 接口**：用于 9\-24V DC 供电、外部同步信号输入/输出（VSYNC）以及 RS485 通信。

![rId37\.png](图片和附件/rId37.png)

- **安装结构**：顶部、底部和背部各提供 4 个 M4 安装孔（螺纹深度 6mm，最大扭矩 0\.4 N·m），机身带有散热结构。

![rId38\.png](图片和附件/rId38.png)



---

## Gemini 435Le 参数的深度图像处理

### 1\. 相机参数提取与仿真数据生成

在仿真环境中，我们首先将官方参数转化为代码变量，并模拟一个包含“2 米处背景墙”和“1 米处矩形障碍物”的测试场景。

**提取的核心参数：**

- **分辨率**：1280 × 800 \(Y16 格式\)

- **视场角 \(FoV\)**：水平 90°，垂直 65°

- **物理误差**：2m 处深度精度误差在 1% 以内（模拟加入 20mm 的高斯噪声）

**代码文件：**

```Python
import cv2
import numpy as np

# 1. 提取 435Le 参数
W, H = 1280, 800
FOV_H, FOV_V = np.deg2rad(90), np.deg2rad(65) # 90度 x 65度
rng = np.random.default_rng(42)

# 2. 初始化 16位 深度图 (Y16格式)
depth = np.zeros((H, W), dtype=np.uint16)
y, x = np.mgrid[0:H, 0:W]

# 3. 模拟 2米 (2000mm) 处的背景墙，并加上 1% 的物理误差噪声 (20mm)
background = np.full((H, W), 2000, dtype=np.float32)
noise = rng.normal(0, 20, size=(H, W)) 
background = np.clip(background + noise, 0, 65535).astype(np.uint16)

# 4. 模拟 1米 (1000mm) 处的矩形障碍物
obstacle_mask = (x > 400) & (x < 800) & (y > 200) & (y < 600)
obstacle = np.full((H, W), 1000, dtype=np.float32)
obstacle_noise = rng.normal(0, 10, size=(H, W)) 
obstacle = np.clip(obstacle + obstacle_noise, 0, 65535).astype(np.uint16)

# 5. 合成图像：把障碍物贴到背景上
depth = background
depth[obstacle_mask] = obstacle[obstacle_mask]

# 6. 模拟相机视野边缘的无效值 (0表示测不到)
depth[:, :50] = 0
depth[:, -50:] = 0

# 保存输出
cv2.imwrite("sim/output/real_depth16.png", depth)
print("已生成真实参数仿真深度图: sim/output/real_depth16.png")
```

**输出文件**：`sim/output/real_depth16.png`（包含真实物理噪点的 16 位深度图）

### 2\. 深度图像处理与 3D 点云重建

得到带有噪点的原始深度图后，我们需要使用 OpenCV 进行滤波去噪，并将其反投影到 3D 空间。

**核心原理**：

1. **图像处理**：使用中值滤波 \(`cv2.medianBlur`\) 滤除深度图边缘的散斑噪声。

2. **伪彩色映射**：使用 JET 色带将距离映射为颜色（近距离蓝色，远距离红色），以便人眼观察。

3. **内参反投影**：根据 FoV 计算焦距 $f_x, f_y$，利用公式 $X = (u-c_x)Z/f_x$ 和 $Y = (v-c_y)Z/f_y$ 将 2D 像素还原为 3D 点云数据。

**代码文件：****`sim/process_depth.py`**

```Python
import cv2
import numpy as np
import os

# 提取的相机内参 (根据 90x65 度视场角计算得出)
W, H = 1280, 800
FOV_H, FOV_V = np.deg2rad(90), np.deg2rad(65)
fx = W / (2 * np.tan(FOV_H / 2)) # 焦距 X
fy = H / (2 * np.tan(FOV_V / 2)) # 焦距 Y
cx, cy = W / 2, H / 2            # 光心

DEPTH_PATH = "sim/output/real_depth16.png"
depth = cv2.imread(DEPTH_PATH, cv2.IMREAD_UNCHANGED)

# 1. 图像处理：中值滤波去噪
depth_float = depth.astype(np.float32)
depth_filtered = cv2.medianBlur(depth_float, 5)
depth_filtered = depth_filtered.astype(np.uint16)

# 2. 伪彩色渲染 (生成可视化图)
valid = depth[depth > 0]
dmin, dmax = np.percentile(valid, [1, 99])
depth_clip = np.clip(depth.astype(np.float32), dmin, dmax)
depth_norm = ((depth_clip - dmin) / (dmax - dmin) * 255).astype(np.uint8)
depth_norm[depth == 0] = 0
depth_color = cv2.applyColorMap(depth_norm, cv2.COLORMAP_JET)
cv2.imwrite("sim/output/real_depth_vis.png", depth_color)

# 3. 深度图转 3D 点云 (利用内参计算 X, Y, Z)
ys, xs = np.where(depth_filtered > 0)
z_vals = depth_filtered[ys, xs].astype(np.float32) / 1000.0 # 转成米 (m)

x_vals = (xs - cx) * z_vals / fx
y_vals = (ys - cy) * z_vals / fy

points = np.stack((x_vals, y_vals, z_vals), axis=-1)

# 4. 将点云保存为 .ply 格式
ply_header = f"""ply
format ascii 1.0
element vertex {len(points)}
property float x
property float y
property float z
end_header
"""
with open("sim/output/cloud.ply", "w") as f:
    f.write(ply_header)
    np.savetxt(f, points, fmt="%.4f %.4f %.4f")

print("处理完成！已生成：")
print("1. 滤波后伪彩图: sim/output/real_depth_vis.png")
print("2. 3D点云文件: sim/output/cloud.ply")
```

### 

**可视化效果预览**：

![real\_depth\_vis\.png](图片和附件/real_depth_vis.png)


*图：基于 435Le 物理参数生成的仿真深度处理结果（红色背景模拟2m墙面，蓝色方块模拟1m障碍物，边缘黑色为无效值）*

### 3\. 环境复现指南

若要在其他机器上复现此仿真流程，请按以下步骤操作：

1. **激活专属 Conda 环境**：

```Bash
conda activate orbbec_wiki
```

2. **进入项目目录**：

```Bash
cd ~/depth_demo
```

3. **生成数据**：

```Bash
python sim/gen_real_sim.py
```

4. **处理数据与生成点云**：

```Bash
python sim/process_depth.py
```

